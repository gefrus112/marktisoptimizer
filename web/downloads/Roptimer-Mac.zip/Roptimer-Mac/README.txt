ROPTIMER MAC COMPANION V3.1
===========================

1. Keep this folder together. Do not move individual files.
2. Right-click "Roptimer Mac.app" and choose Open the first time.
3. Or double-click "Roptimer Mac.command" for the optimizer.
4. Use "Roptimer Boost.command" for the safe CLI, for example:
     ./Roptimer\ Boost.command --preview
     ./Roptimer\ Boost.command --apply --mode "Reduce building lag" --no-launch
     ./Roptimer\ Boost.command --restore
5. Read docs/MAC.md, docs/CLI.md, and docs/HOW_IT_WORKS.md for details.

Requires Python 3.10+ with Tkinter. On macOS, the official python.org build
includes Tkinter. This package is unsigned, so macOS Gatekeeper may require
right-click -> Open on first launch.

Roptimer only writes local ClientAppSettings.json files and keeps backups.
No injection, memory edits, telemetry disabling, or game script execution.
